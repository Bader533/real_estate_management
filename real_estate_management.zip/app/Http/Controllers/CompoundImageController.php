<?php

namespace App\Http\Controllers;

use App\Models\CompoundImage;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;


class CompoundImageController extends Controller
{
    public function deleteImage($id)
    {
        $image = CompoundImage::where('id', $id)->first();
        $isDeleted = $image->delete();
        return response()->json(
            ['message' => $isDeleted ? 'Deleted successfully' : 'Delete failed!'],
            $isDeleted ? Response::HTTP_OK : Response::HTTP_BAD_REQUEST
        );
    }
}
