<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CompoundController;
use App\Http\Controllers\CompoundImageController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\PropertyOwnerController;
use Illuminate\Support\Facades\Route;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::middleware('guest:owner,admin,employee')->group(function () {
    Route::get('{guard}/login', [AuthController::class, 'showLogin'])->name('dashboard.login');
    Route::post('login', [AuthController::class, 'login'])->name('login');
});
// Route::get('lang/{lang}', ['as' => 'lang.switch', 'uses' => 'App\Http\Controllers\LanguageController@switchLang']);
Route::group(
    [
        'prefix' => LaravelLocalization::setLocale(),
        'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'localeViewPath', 'auth:admin,employee,owner']
    ],
    function () {
        Route::view('', 'dashboard.home_page')->name('page.home');
        Route::resource('owner', PropertyOwnerController::class);
        Route::resource('compound', CompoundController::class);
        // Route::get('search', [Controller::class, 'search'])->name('search');
        Route::delete('compound/image/{id}', [CompoundImageController::class, 'deleteImage'])->name('compound.image.delete');
    }
);
