<?php

namespace App\Traits;

use Illuminate\Support\Str;

trait  Image
{
    function saveImage($image, $path, $imageModel, $id, $forginId)
    {
        $file_name = str::random(10) . '_' . time() . str::random(10) . '.' . $image->getClientOriginalExtension();
        // $path = 'images/compound';
        $image->move($path, $file_name);
        // $newImage = new CompoundImage();
        $imageModel->image_url = $path . $file_name;
        $imageModel->$forginId = $id;
        $isSaved = $imageModel->save();
    }
}
