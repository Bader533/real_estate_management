<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompoundImage extends Model
{
    use HasFactory;

    public function compound()
    {
        return $this->belongsTo(Compound::class);
    }
}
