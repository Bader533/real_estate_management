<?php $__env->startSection('css'); ?>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<?php if(app()->getLocale() == 'ar'): ?>
<style>
    #kt_content_container {
        direction: rtl;
    }
</style>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename', __('site.owners')); ?>
<?php $__env->startSection('object', __('site.owner_info')); ?>

<?php $__env->startSection('content'); ?>
<div id="kt_content_container" class="container-xxl">
    <div class="card">
        <div id="add-search" class="card-header border-0 pt-5">

            <div class="card-title">
                <div class="d-flex align-items-center position-relative my-1">
                    <span class="svg-icon svg-icon-1 position-absolute ms-6">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1"
                                transform="rotate(45 17.0365 15.1223)" fill="black" />
                            <path
                                d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z"
                                fill="black" />
                        </svg>
                    </span>
                    <input type="text" data-kt-customer-table-filter="search" id="search"
                        class="form-control form-control-solid w-250px ps-15"
                        placeholder="<?php echo e(__('site.search_tenants')); ?>" />
                </div>
            </div>

        </div><br>

        <div class="card-body pt-0">
            <div class="container text-center">
                <div class="row row-cols-2">
                    <table class="table align-middle table-row-dashed fs-6 gy-5" id="kt_customers_table">

                        <thead>

                            <tr class="text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                <th class=""><?php echo e(__('site.name')); ?></th>
                                <th class=""><?php echo e(__('site.email')); ?></th>
                                <th class=""><?php echo e(__('site.phone')); ?></th>
                                <th class=""><?php echo e(__('site.compounds')); ?></th>
                                <th class=""><?php echo e(__('site.buildings')); ?></th>
                                <th class=""><?php echo e(__('site.apartments')); ?></th>
                            </tr>

                        </thead>

                        <tbody class="" id="div_content_data">
                            <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <?php if($owner->name == null): ?>
                                    <?php echo e($owner->company_name); ?>

                                    <?php else: ?>
                                    <?php echo e($owner->name); ?>

                                    <?php endif; ?>

                                </td>

                                <td>
                                    <?php echo e($owner->email); ?>

                                </td>

                                <td>
                                    <?php echo e($owner->phone); ?>

                                </td>

                                <td>
                                    <?php echo e($owner->compounds->count()); ?>

                                </td>

                                <td>
                                    <?php echo e($owner->buildings->count()); ?>

                                </td>

                                <td>
                                    <?php echo e($owner->apartments->count()); ?>

                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-sm">
                        <div style="float: right">
                            <?php echo e($owners->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/crud.js')); ?>"></script>
<script>
    $("body").on("keyup", "#search", function() {
            let text = $("#search").val();
            if (text != null) {
                $.ajax({
                    data: {
                        search: text
                    },
                    url: "<?php echo e(route('owner.search.admin')); ?>",
                    method: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        $('#div_content_data').html(data.table_data);
                    }
                }); //end ajax
            }
        }); //end function
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real_estate_management\resources\views/dashboard/admin/owner/index.blade.php ENDPATH**/ ?>