<?php $__env->startComponent('mail::message'); ?>
# Welcome ,<?php echo e($name); ?>


Verify Your Email .
<?php $__env->startComponent('mail::panel'); ?>
Verification Code is : <?php echo e($code); ?>

<?php echo $__env->renderComponent(); ?>
Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\real_estate_management\resources\views/mail/verify-email.blade.php ENDPATH**/ ?>