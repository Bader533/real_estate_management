<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\real_estate_management\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>