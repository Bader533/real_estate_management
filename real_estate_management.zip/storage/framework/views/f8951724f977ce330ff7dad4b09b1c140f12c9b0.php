<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<?php $__env->startSection('pagename'); ?>
<?php $__env->startSection('object'); ?>

<?php $__env->startSection('content'); ?>
<p>home page _ <?php echo e(auth('owner')->id()); ?></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real_estate_management\resources\views/dashboard/home_page.blade.php ENDPATH**/ ?>