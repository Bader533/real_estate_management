@extends('dashboard.index')

@section('css')

@endsection

@section('pagename')
@section('object')

@section('content')

@endsection

@section('js')

@endsection
