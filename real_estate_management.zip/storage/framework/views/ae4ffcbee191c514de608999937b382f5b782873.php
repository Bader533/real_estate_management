<?php $__env->startSection('css'); ?>
<?php if(app()->getLocale() == 'ar'): ?>
<style>
    .row {
        direction: rtl;
    }
</style>
<?php endif; ?>
<style>
    #stretch {
        background-color: #F5F8FA;
    }

    #compound_id,
    #button_compund {
        display: none;
    }

    .data {
        font-size: 22px;
        text-align: center;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagename', __('site.one_tenant')); ?>
<?php $__env->startSection('object', __('site.tenant_info')); ?>

<?php $__env->startSection('content'); ?>
<div id="kt_content_container" class="container-xxl">

    <div class="row gy-5 gx-xl-10">

        <!--begin::Rental details-->
        <div class="col-xl-6">

            <div class="card card-xl-stretch mb-5 mb-xl-10">

                <div class="card-header border-0 pt-5">
                    <h3 class="card-title align-items-start flex-column">
                        <span class="card-label fw-bolder fs-3 mb-1"><?php echo e(__('site.tenant_data')); ?></span>
                    </h3>
                </div>
                <div class="card-body pt-5">


                    <!--begin::contract_starting_date-->
                    <div class="row mb-7">

                        <label class="col-lg-4 fw-bold text-muted"><?php echo e(__('site.name')); ?></label>

                        <div class="col-lg-8 fv-row">
                            <span class="fw-bold text-gray-800 fs-6"><?php echo e($tenant->name); ?></span>
                        </div>

                    </div>
                    <!--end::contract_starting_date-->

                    <!--begin::contract_end_date-->
                    <div class="row mb-7">

                        <label class="col-lg-4 fw-bold text-muted"><?php echo e(__('site.phone')); ?></label>

                        <div class="col-lg-8">
                            <span class="fw-bold text-gray-800 fs-6"><?php echo e($tenant->phone); ?></span>
                        </div>

                    </div>
                    <!--end::contract_end_date-->

                    <!--begin::total_rental_amount-->
                    <div class="row mb-7">

                        <label class="col-lg-4 fw-bold text-muted"><?php echo e(__('site.email')); ?></label>

                        <div class="col-lg-8">
                            <span class="fw-bolder fs-6 text-gray-800"><?php echo e($tenant->email); ?></span>
                        </div>

                    </div>
                    <!--end::total_rental_amount-->

                </div>
            </div>

        </div>
        <!--end::Rental details-->

        <!--begin::tenant details-->
        <div class="col-xl-6">

            <div class="card card-xl-stretch mb-5 mb-xl-10">

                <div class="card-header border-0 pt-5">
                    <h3 class="card-title align-items-start flex-column">
                        <span class="card-label fw-bolder fs-3 mb-1"><?php echo e(__('site.details')); ?></span>
                    </h3>
                </div>
                <?php if($tenant->tenantInfos != null): ?>
                <div class="card-body pt-5">


                    <!--begin::contract_starting_date-->
                    <div class="row mb-7">

                        <label class="col-lg-4 fw-bold text-muted"><?php echo e(__('site.payment')); ?></label>

                        <div class="col-lg-8 fv-row">
                            <span class="fw-bold text-gray-800 fs-6"><?php echo e($totalPayment); ?></span>
                        </div>

                    </div>
                    <!--end::contract_starting_date-->

                    <!--begin::contract_end_date-->
                    <div class="row mb-7">

                        <label class="col-lg-4 fw-bold text-muted"><?php echo e(__('site.cleanliness')); ?></label>

                        <div class="col-lg-8">
                            <span class="fw-bold text-gray-800 fs-6"><?php echo e($totalApartmentClean); ?></span>
                        </div>

                    </div>
                    <!--end::contract_end_date-->

                    <!--begin::total_rental_amount-->
                    <div class="row mb-7">

                        <label class="col-lg-4 fw-bold text-muted"><?php echo e(__('site.attention_at_home')); ?></label>

                        <div class="col-lg-8">
                            <span class="fw-bolder fs-6 text-gray-800"><?php echo e($totalApartmentInterest); ?></span>
                        </div>

                    </div>
                    <!--end::total_rental_amount-->

                    <!--begin::total_rental_amount-->
                    <div class="row mb-7">

                        <label class="col-lg-4 fw-bold text-muted"><?php echo e(__('site.annoyance')); ?></label>

                        <div class="col-lg-8">
                            <span class="fw-bolder fs-6 text-gray-800"><?php echo e($totalAnnoyance); ?></span>
                        </div>

                    </div>
                    <!--end::total_rental_amount-->

                </div>
                <?php else: ?>
                <div class="card-body pt-5">

                    <p class="data"> <?php echo e(__('site.no_rating')); ?></p>

                </div>
                <?php endif; ?>

            </div>

        </div>
        <!--end::tenant details-->

        <!--begin::tenant details-->
        <div class="col-xl-12">

            <div class="card card-xl-stretch mb-5 mb-xl-10">

                <div class="card-header border-0 pt-5">
                    <h3 class="card-title align-items-start flex-column">
                        <span class="card-label fw-bolder fs-3 mb-1"><?php echo e(__('site.details')); ?></span>
                    </h3>
                </div>
                <?php if($tenant->tenantInfos != null): ?>
                <div class="card-body pt-0">
                    <div class="container text-center">
                        <div class="row row-cols-2">
                            <table class="table align-middle table-row-dashed fs-6 gy-5" id="kt_customers_table">
                                <!--begin::Table head-->
                                <thead>
                                    <!--begin::Table row-->
                                    <tr class="text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                        <th class="min-w-125px"> <?php echo e(__('site.description')); ?></th>
                                        <th class="min-w-125px"> <?php echo e(__('site.date')); ?></th>
                                    </tr>
                                    <!--end::Table row-->
                                </thead>
                                <!--end::Table head-->
                                <!--begin::Table body-->
                                <tbody class="fw-bold text-gray-600" id="div_content_data">
                                    <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($info->description); ?>

                                        </td>
                                        <td>
                                            <?php echo e($info->created_at); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <!--end::Table body-->
                            </table>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="card-body pt-5">

                    <p class="data"> <?php echo e(__('site.no_rating')); ?></p>

                </div>
                <?php endif; ?>

            </div>

        </div>
        <!--end::tenant details-->


    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real_estate_management\resources\views/dashboard/owner/tenant/advanced_search.blade.php ENDPATH**/ ?>